// Zepto Clone JavaScript Application

// Application State
const AppState = {
    currentPage: 'home',
    currentUser: null,
    currentLocation: null,
    cart: [],
    products: [],
    categories: [],
    locations: [],
    currentOrder: null,
    searchResults: []
};

// Product Data
const PRODUCT_DATA = {
    "products": [
        {"id": 1, "name": "Fresh Bananas (1 dozen)", "price": 48, "category": "fruits", "image": "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=300", "description": "Fresh yellow bananas, perfect for breakfast", "stock": 50, "rating": 4.5},
        {"id": 2, "name": "Amul Taaza Milk 1L", "price": 65, "category": "dairy", "image": "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=300", "description": "Fresh full cream milk", "stock": 30, "rating": 4.8},
        {"id": 3, "name": "Red Apples (1kg)", "price": 120, "category": "fruits", "image": "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=300", "description": "Crisp and sweet red apples", "stock": 25, "rating": 4.6},
        {"id": 4, "name": "Fresh Tomatoes (1kg)", "price": 28, "category": "vegetables", "image": "https://images.unsplash.com/photo-1546094096-0df4bcaaa337?w=300", "description": "Fresh red tomatoes", "stock": 40, "rating": 4.3},
        {"id": 5, "name": "White Onions (1kg)", "price": 37, "category": "vegetables", "image": "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=300", "description": "Fresh white onions", "stock": 35, "rating": 4.2},
        {"id": 6, "name": "Britannia Bread 400g", "price": 48, "category": "bakery", "image": "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=300", "description": "Whole wheat bread", "stock": 20, "rating": 4.4},
        {"id": 7, "name": "Amul Butter 100g", "price": 58, "category": "dairy", "image": "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=300", "description": "Fresh salted butter", "stock": 15, "rating": 4.7},
        {"id": 8, "name": "Farm Fresh Eggs (6 pcs)", "price": 52, "category": "dairy", "image": "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?w=300", "description": "Free range chicken eggs", "stock": 18, "rating": 4.5},
        {"id": 9, "name": "Lays Classic Chips 90g", "price": 30, "category": "snacks", "image": "https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=300", "description": "Classic salted potato chips", "stock": 45, "rating": 4.3},
        {"id": 10, "name": "Coca-Cola 1.25L", "price": 60, "category": "beverages", "image": "https://images.unsplash.com/photo-1561758033-d89a9ad46330?w=300", "description": "Refreshing cola drink", "stock": 22, "rating": 4.6},
        {"id": 11, "name": "Basmati Rice 1kg", "price": 110, "category": "staples", "image": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=300", "description": "Premium basmati rice", "stock": 12, "rating": 4.8},
        {"id": 12, "name": "Sunflower Oil 1L", "price": 145, "category": "staples", "image": "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=300", "description": "Pure sunflower cooking oil", "stock": 8, "rating": 4.4},
        {"id": 13, "name": "Orange Juice 1L", "price": 99, "category": "beverages", "image": "https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?w=300", "description": "Fresh orange juice", "stock": 16, "rating": 4.5},
        {"id": 14, "name": "Green Grapes 500g", "price": 80, "category": "fruits", "image": "https://images.unsplash.com/photo-1537640538966-79f369143f8f?w=300", "description": "Sweet green grapes", "stock": 20, "rating": 4.4},
        {"id": 15, "name": "Potato 1kg", "price": 25, "category": "vegetables", "image": "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=300", "description": "Fresh potatoes", "stock": 50, "rating": 4.1},
        {"id": 16, "name": "Maggi Noodles 280g", "price": 55, "category": "snacks", "image": "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=300", "description": "Instant masala noodles", "stock": 30, "rating": 4.6},
        {"id": 17, "name": "Greek Yogurt 400g", "price": 85, "category": "dairy", "image": "https://images.unsplash.com/photo-1571212515416-cd2468ee2b7d?w=300", "description": "Thick Greek yogurt", "stock": 12, "rating": 4.7},
        {"id": 18, "name": "Colgate Toothpaste 200g", "price": 102, "category": "personal care", "image": "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300", "description": "Advanced whitening toothpaste", "stock": 25, "rating": 4.5},
        {"id": 19, "name": "Detergent Powder 1kg", "price": 155, "category": "household", "image": "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=300", "description": "Ultra clean washing powder", "stock": 10, "rating": 4.3},
        {"id": 20, "name": "Green Capsicum 500g", "price": 45, "category": "vegetables", "image": "https://images.unsplash.com/photo-1525607551316-4a8e16d1f9ba?w=300", "description": "Fresh green bell peppers", "stock": 18, "rating": 4.2}
    ],
    "categories": [
        {"id": "fruits", "name": "Fruits", "icon": "🍎", "color": "#4ade80"},
        {"id": "vegetables", "name": "Vegetables", "icon": "🥕", "color": "#4ade80"}, 
        {"id": "dairy", "name": "Dairy", "icon": "🥛", "color": "#60a5fa"},
        {"id": "snacks", "name": "Snacks", "icon": "🍿", "color": "#fbbf24"},
        {"id": "beverages", "name": "Beverages", "icon": "🥤", "color": "#f87171"},
        {"id": "staples", "name": "Staples", "icon": "🌾", "color": "#a78bfa"},
        {"id": "personal care", "name": "Personal Care", "icon": "🧴", "color": "#34d399"},
        {"id": "household", "name": "Household", "icon": "🏠", "color": "#fb7185"},
        {"id": "bakery", "name": "Bakery", "icon": "🍞", "color": "#fcd34d"}
    ],
    "locations": [
        {"id": 1, "name": "Koramangala", "deliveryTime": "8-12 mins"},
        {"id": 2, "name": "Indiranagar", "deliveryTime": "10-15 mins"},
        {"id": 3, "name": "HSR Layout", "deliveryTime": "12-18 mins"},
        {"id": 4, "name": "Whitefield", "deliveryTime": "15-20 mins"},
        {"id": 5, "name": "Electronic City", "deliveryTime": "18-25 mins"}
    ]
};

// Utility Functions
const Utils = {
    formatPrice: (price) => `₹${price}`,
    formatRating: (rating) => `⭐ ${rating}`,
    generateId: () => Date.now().toString(36) + Math.random().toString(36).substr(2),
    
    showLoading: () => {
        const loadingOverlay = document.getElementById('loading-overlay');
        if (loadingOverlay) loadingOverlay.classList.remove('hidden');
    },
    
    hideLoading: () => {
        const loadingOverlay = document.getElementById('loading-overlay');
        if (loadingOverlay) loadingOverlay.classList.add('hidden');
    },
    
    showToast: (message, type = 'success') => {
        const toastContainer = document.getElementById('toast-container');
        if (!toastContainer) return;
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `<span>${type === 'success' ? '✅' : '❌'}</span><span>${message}</span>`;
        
        toastContainer.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 100);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },
    
    debounce: (func, wait) => {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
};

// Storage Management (using window object instead of localStorage)
const Storage = {
    save: (key, data) => {
        try {
            window.appStorage = window.appStorage || {};
            window.appStorage[key] = JSON.stringify(data);
        } catch (error) {
            console.error('Storage save error:', error);
        }
    },
    
    load: (key, defaultValue = null) => {
        try {
            window.appStorage = window.appStorage || {};
            const data = window.appStorage[key];
            return data ? JSON.parse(data) : defaultValue;
        } catch (error) {
            console.error('Storage load error:', error);
            return defaultValue;
        }
    },
    
    remove: (key) => {
        try {
            if (window.appStorage) delete window.appStorage[key];
        } catch (error) {
            console.error('Storage remove error:', error);
        }
    }
};

// Navigation Management
const Navigation = {
    showPage: (pageId) => {
        console.log(`Navigating to page: ${pageId}`);
        
        // Hide all pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.add('hidden');
        });
        
        // Show target page
        const targetPage = document.getElementById(`${pageId}-page`);
        if (targetPage) {
            targetPage.classList.remove('hidden');
            AppState.currentPage = pageId;
            
            // Initialize page-specific functionality
            setTimeout(() => {
                if (pageId === 'cart') {
                    CartPage.render();
                } else if (pageId === 'checkout') {
                    CheckoutManager.init();
                } else if (pageId === 'tracking') {
                    OrderTracking.init();
                } else if (pageId === 'profile') {
                    UserManager.updateProfileDisplay();
                } else if (pageId === 'products') {
                    ProductManager.ensureFiltersSetup();
                }
            }, 50);
        }
    },
    
    goBack: () => {
        if (AppState.currentPage === 'products' || AppState.currentPage === 'cart') {
            Navigation.showPage('home');
        } else if (AppState.currentPage === 'checkout') {
            Navigation.showPage('cart');
        } else {
            Navigation.showPage('home');
        }
    }
};

// Cart Management
const CartManager = {
    init: () => {
        AppState.cart = Storage.load('cart', []);
        CartManager.updateCartDisplay();
    },
    
    addItem: (productId, quantity = 1) => {
        console.log(`Adding product ${productId} to cart`);
        const product = AppState.products.find(p => p.id === productId);
        if (!product) {
            console.error(`Product ${productId} not found`);
            return;
        }
        
        const existingItem = AppState.cart.find(item => item.productId === productId);
        
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            AppState.cart.push({
                productId: productId,
                quantity: quantity,
                product: product
            });
        }
        
        Storage.save('cart', AppState.cart);
        CartManager.updateCartDisplay();
        Utils.showToast(`${product.name} added to cart`);
    },
    
    updateQuantity: (productId, quantity) => {
        const item = AppState.cart.find(item => item.productId === productId);
        if (item) {
            if (quantity <= 0) {
                CartManager.removeItem(productId);
            } else {
                item.quantity = quantity;
                Storage.save('cart', AppState.cart);
                CartManager.updateCartDisplay();
                if (AppState.currentPage === 'cart') {
                    CartPage.render();
                }
            }
        }
    },
    
    removeItem: (productId) => {
        AppState.cart = AppState.cart.filter(item => item.productId !== productId);
        Storage.save('cart', AppState.cart);
        CartManager.updateCartDisplay();
        if (AppState.currentPage === 'cart') {
            CartPage.render();
        }
        Utils.showToast('Item removed from cart');
    },
    
    clearCart: () => {
        AppState.cart = [];
        Storage.save('cart', AppState.cart);
        CartManager.updateCartDisplay();
    },
    
    getCartTotal: () => {
        return AppState.cart.reduce((total, item) => {
            return total + (item.product.price * item.quantity);
        }, 0);
    },
    
    getCartCount: () => {
        return AppState.cart.reduce((count, item) => count + item.quantity, 0);
    },
    
    updateCartDisplay: () => {
        const cartCount = CartManager.getCartCount();
        const cartCountElement = document.getElementById('cart-count');
        if (cartCountElement) {
            cartCountElement.textContent = cartCount;
            cartCountElement.style.display = cartCount > 0 ? 'flex' : 'none';
        }
        
        // Update all product cards
        document.querySelectorAll('.product-card').forEach(card => {
            const productId = parseInt(card.dataset.productId);
            const cartItem = AppState.cart.find(item => item.productId === productId);
            const addBtn = card.querySelector('.add-to-cart-btn');
            const quantityControls = card.querySelector('.quantity-controls');
            const quantityDisplay = card.querySelector('.quantity-display');
            
            if (cartItem && cartItem.quantity > 0) {
                if (addBtn) addBtn.style.display = 'none';
                if (quantityControls) quantityControls.style.display = 'flex';
                if (quantityDisplay) quantityDisplay.textContent = cartItem.quantity;
            } else {
                if (addBtn) addBtn.style.display = 'block';
                if (quantityControls) quantityControls.style.display = 'none';
            }
        });
    }
};

// Search Management
const SearchManager = {
    init: () => {
        const searchInput = document.getElementById('search-input');
        const searchResults = document.getElementById('search-results');
        
        if (searchInput) {
            searchInput.addEventListener('input', Utils.debounce((e) => {
                const query = e.target.value.trim();
                if (query.length > 0) {
                    SearchManager.performSearch(query);
                } else {
                    SearchManager.hideResults();
                }
            }, 300));
            
            searchInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    const query = e.target.value.trim();
                    if (query.length > 0) {
                        console.log(`Searching for: ${query}`);
                        SearchManager.navigateToSearch(query);
                    }
                }
            });
            
            document.addEventListener('click', (e) => {
                if (!searchInput.contains(e.target) && !searchResults?.contains(e.target)) {
                    SearchManager.hideResults();
                }
            });
        }
    },
    
    performSearch: (query) => {
        const results = AppState.products.filter(product =>
            product.name.toLowerCase().includes(query.toLowerCase()) ||
            product.category.toLowerCase().includes(query.toLowerCase())
        ).slice(0, 5);
        
        SearchManager.displayResults(results);
    },
    
    displayResults: (results) => {
        const searchResults = document.getElementById('search-results');
        if (!searchResults) return;
        
        if (results.length === 0) {
            searchResults.innerHTML = '<div class="search-result-item">No products found</div>';
        } else {
            searchResults.innerHTML = results.map(product => `
                <div class="search-result-item" onclick="SearchManager.selectProduct(${product.id})">
                    <img src="${product.image}" alt="${product.name}" class="search-result-image">
                    <div class="search-result-info">
                        <div class="search-result-name">${product.name}</div>
                        <div class="search-result-price">${Utils.formatPrice(product.price)}</div>
                    </div>
                </div>
            `).join('');
        }
        
        searchResults.classList.remove('hidden');
    },
    
    hideResults: () => {
        const searchResults = document.getElementById('search-results');
        if (searchResults) searchResults.classList.add('hidden');
    },
    
    selectProduct: (productId) => {
        console.log(`Selected product: ${productId}`);
        SearchManager.hideResults();
        Navigation.showPage('products');
        setTimeout(() => ProductManager.highlightProduct(productId), 100);
    },
    
    navigateToSearch: (query) => {
        SearchManager.hideResults();
        Navigation.showPage('products');
        setTimeout(() => ProductManager.searchProducts(query), 100);
    }
};

// Product Management
const ProductManager = {
    currentFilter: 'all',
    
    init: () => {
        AppState.products = PRODUCT_DATA.products;
        AppState.categories = PRODUCT_DATA.categories;
        ProductManager.renderCategories();
        ProductManager.renderFeaturedProducts();
        ProductManager.renderAllProducts();
        ProductManager.setupFilters();
    },
    
    renderCategories: () => {
        const categoriesGrid = document.getElementById('categories-grid');
        if (!categoriesGrid) return;
        
        categoriesGrid.innerHTML = AppState.categories.map(category => `
            <div class="category-card" onclick="ProductManager.filterByCategory('${category.id}')">
                <div class="category-icon">${category.icon}</div>
                <div class="category-name">${category.name}</div>
            </div>
        `).join('');
    },
    
    renderFeaturedProducts: () => {
        const featuredGrid = document.getElementById('featured-products-grid');
        if (!featuredGrid) return;
        
        const featuredProducts = AppState.products.slice(0, 8);
        featuredGrid.innerHTML = featuredProducts.map(product => 
            ProductManager.createProductCard(product)
        ).join('');
        
        ProductManager.attachProductCardEvents(featuredGrid);
    },
    
    renderAllProducts: (products = null) => {
        const productsGrid = document.getElementById('all-products-grid');
        if (!productsGrid) return;
        
        const productsToRender = products || AppState.products;
        productsGrid.innerHTML = productsToRender.map(product => 
            ProductManager.createProductCard(product)
        ).join('');
        
        ProductManager.attachProductCardEvents(productsGrid);
        CartManager.updateCartDisplay();
    },
    
    attachProductCardEvents: (container) => {
        // Add to cart buttons
        container.querySelectorAll('.add-to-cart-btn').forEach(btn => {
            btn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                const productId = parseInt(this.dataset.productId);
                console.log(`Add to cart clicked for product: ${productId}`);
                CartManager.addItem(productId);
            };
        });
        
        // Quantity buttons
        container.querySelectorAll('.quantity-btn').forEach(btn => {
            btn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                const productId = parseInt(this.dataset.productId);
                const action = this.dataset.action;
                const currentItem = AppState.cart.find(item => item.productId === productId);
                const currentQuantity = currentItem ? currentItem.quantity : 0;
                
                if (action === 'increase') {
                    CartManager.updateQuantity(productId, currentQuantity + 1);
                } else if (action === 'decrease') {
                    CartManager.updateQuantity(productId, currentQuantity - 1);
                }
            };
        });
        
        // Remove buttons
        container.querySelectorAll('.remove-item-btn').forEach(btn => {
            btn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                const productId = parseInt(this.dataset.productId);
                CartManager.removeItem(productId);
            };
        });
    },
    
    createProductCard: (product) => {
        const cartItem = AppState.cart.find(item => item.productId === product.id);
        const quantity = cartItem ? cartItem.quantity : 0;
        
        return `
            <div class="product-card" data-product-id="${product.id}">
                <img src="${product.image}" alt="${product.name}" class="product-image" loading="lazy">
                <div class="product-info">
                    <div class="product-name">${product.name}</div>
                    <div class="product-price">${Utils.formatPrice(product.price)}</div>
                    <div class="product-rating">${Utils.formatRating(product.rating)} • ${product.stock} left</div>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" data-product-id="${product.id}" 
                                style="${quantity > 0 ? 'display: none' : ''}">
                            Add to Cart
                        </button>
                        <div class="quantity-controls" style="${quantity > 0 ? 'display: flex' : 'display: none'}">
                            <button class="quantity-btn" data-product-id="${product.id}" data-action="decrease">-</button>
                            <span class="quantity-display">${quantity}</span>
                            <button class="quantity-btn" data-product-id="${product.id}" data-action="increase">+</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },
    
    setupFilters: () => {
        const filterTabs = document.getElementById('filter-tabs');
        if (!filterTabs) return;
        
        const categories = ['all', ...AppState.categories.map(cat => cat.id)];
        filterTabs.innerHTML = categories.map(category => `
            <button class="filter-tab ${category === 'all' ? 'active' : ''}" 
                    onclick="ProductManager.filterByCategory('${category}')">
                ${category === 'all' ? 'All' : AppState.categories.find(c => c.id === category)?.name || category}
            </button>
        `).join('');
    },
    
    ensureFiltersSetup: () => {
        if (!document.getElementById('filter-tabs').innerHTML) {
            ProductManager.setupFilters();
        }
    },
    
    filterByCategory: (categoryId) => {
        console.log(`Filtering by category: ${categoryId}`);
        Navigation.showPage('products');
        ProductManager.currentFilter = categoryId;
        
        setTimeout(() => {
            // Update filter tabs
            document.querySelectorAll('.filter-tab').forEach(tab => {
                const tabCategory = tab.textContent.toLowerCase();
                const isActive = (categoryId === 'all' && tabCategory === 'all') || 
                               (categoryId !== 'all' && tabCategory === AppState.categories.find(c => c.id === categoryId)?.name.toLowerCase());
                tab.classList.toggle('active', isActive);
            });
            
            // Filter products
            let filteredProducts;
            if (categoryId === 'all') {
                filteredProducts = AppState.products;
            } else {
                filteredProducts = AppState.products.filter(product => 
                    product.category.toLowerCase() === categoryId.toLowerCase()
                );
            }
            
            ProductManager.renderAllProducts(filteredProducts);
        }, 50);
    },
    
    searchProducts: (query) => {
        const filteredProducts = AppState.products.filter(product =>
            product.name.toLowerCase().includes(query.toLowerCase()) ||
            product.category.toLowerCase().includes(query.toLowerCase())
        );
        
        // Update filter tabs to show "All" as active
        document.querySelectorAll('.filter-tab').forEach(tab => {
            tab.classList.toggle('active', tab.textContent.toLowerCase() === 'all');
        });
        
        ProductManager.renderAllProducts(filteredProducts);
        Utils.showToast(`Found ${filteredProducts.length} products for "${query}"`);
    },
    
    highlightProduct: (productId) => {
        setTimeout(() => {
            const productCard = document.querySelector(`[data-product-id="${productId}"]`);
            if (productCard) {
                productCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                productCard.style.boxShadow = '0 0 20px rgba(88, 47, 255, 0.3)';
                setTimeout(() => { productCard.style.boxShadow = ''; }, 2000);
            }
        }, 100);
    }
};

// Cart Page Management
const CartPage = {
    render: () => {
        const cartItemsContainer = document.getElementById('cart-items-container');
        const emptyCart = document.getElementById('empty-cart');
        const cartSummary = document.getElementById('cart-summary');
        
        if (AppState.cart.length === 0) {
            if (cartItemsContainer) cartItemsContainer.innerHTML = '';
            if (emptyCart) emptyCart.classList.remove('hidden');
            if (cartSummary) cartSummary.classList.add('hidden');
        } else {
            if (emptyCart) emptyCart.classList.add('hidden');
            if (cartSummary) cartSummary.classList.remove('hidden');
            
            if (cartItemsContainer) {
                cartItemsContainer.innerHTML = AppState.cart.map(item => `
                    <div class="cart-item">
                        <img src="${item.product.image}" alt="${item.product.name}" class="cart-item-image">
                        <div class="cart-item-info">
                            <div class="cart-item-name">${item.product.name}</div>
                            <div class="cart-item-price">${Utils.formatPrice(item.product.price * item.quantity)}</div>
                        </div>
                        <div class="cart-item-actions">
                            <div class="quantity-controls">
                                <button class="quantity-btn" onclick="CartManager.updateQuantity(${item.productId}, ${item.quantity - 1})">-</button>
                                <span class="quantity-display">${item.quantity}</span>
                                <button class="quantity-btn" onclick="CartManager.updateQuantity(${item.productId}, ${item.quantity + 1})">+</button>
                            </div>
                            <button class="remove-item-btn" onclick="CartManager.removeItem(${item.productId})">🗑️</button>
                        </div>
                    </div>
                `).join('');
            }
            
            CartPage.updateSummary();
        }
    },
    
    updateSummary: () => {
        const itemsTotal = CartManager.getCartTotal();
        const deliveryFee = itemsTotal > 0 ? 29 : 0;
        const totalAmount = itemsTotal + deliveryFee;
        
        const itemsTotalElement = document.getElementById('items-total');
        const deliveryFeeElement = document.getElementById('delivery-fee');
        const totalAmountElement = document.getElementById('total-amount');
        
        if (itemsTotalElement) itemsTotalElement.textContent = Utils.formatPrice(itemsTotal);
        if (deliveryFeeElement) deliveryFeeElement.textContent = Utils.formatPrice(deliveryFee);
        if (totalAmountElement) totalAmountElement.textContent = Utils.formatPrice(totalAmount);
    }
};

// Checkout Management
const CheckoutManager = {
    init: () => {
        CheckoutManager.renderOrderSummary();
    },
    
    renderOrderSummary: () => {
        const checkoutItems = document.getElementById('checkout-items');
        if (!checkoutItems) return;
        
        checkoutItems.innerHTML = AppState.cart.map(item => `
            <div class="checkout-item">
                <div class="checkout-item-info">
                    <div class="checkout-item-name">${item.product.name}</div>
                    <div class="checkout-item-qty">Qty: ${item.quantity}</div>
                </div>
                <div class="checkout-item-price">${Utils.formatPrice(item.product.price * item.quantity)}</div>
            </div>
        `).join('');
        
        const itemsTotal = CartManager.getCartTotal();
        const deliveryFee = 29;
        const totalAmount = itemsTotal + deliveryFee;
        
        const checkoutItemsTotal = document.getElementById('checkout-items-total');
        const checkoutTotalAmount = document.getElementById('checkout-total-amount');
        
        if (checkoutItemsTotal) checkoutItemsTotal.textContent = Utils.formatPrice(itemsTotal);
        if (checkoutTotalAmount) checkoutTotalAmount.textContent = Utils.formatPrice(totalAmount);
    },
    
    processOrder: () => {
        const form = document.getElementById('address-form');
        if (!form || !form.checkValidity()) {
            Utils.showToast('Please fill in all required fields', 'error');
            return;
        }
        
        Utils.showLoading();
        
        setTimeout(() => {
            const orderId = 'ZE' + Utils.generateId().toUpperCase().substr(0, 6);
            AppState.currentOrder = {
                id: orderId,
                items: [...AppState.cart],
                total: CartManager.getCartTotal() + 29,
                status: 'confirmed',
                timestamp: new Date()
            };
            
            const orderHistory = Storage.load('orderHistory', []);
            orderHistory.unshift(AppState.currentOrder);
            Storage.save('orderHistory', orderHistory);
            
            CartManager.clearCart();
            Utils.hideLoading();
            Utils.showToast('Order placed successfully!');
            Navigation.showPage('tracking');
        }, 2000);
    }
};

// Order Tracking
const OrderTracking = {
    init: () => {
        if (!AppState.currentOrder) return;
        
        const orderIdElement = document.getElementById('order-id');
        if (orderIdElement) orderIdElement.textContent = AppState.currentOrder.id;
        
        OrderTracking.startTracking();
    },
    
    startTracking: () => {
        let currentStep = 1;
        const steps = ['confirmed', 'preparing', 'delivery', 'delivered'];
        const stepElements = {
            'confirmed': document.getElementById('step-confirmed'),
            'preparing': document.getElementById('step-preparing'),
            'delivery': document.getElementById('step-delivery'),
            'delivered': document.getElementById('step-delivered')
        };
        const progressFill = document.getElementById('progress-fill');
        const deliveryTimeElement = document.getElementById('delivery-time');
        
        const updateProgress = () => {
            if (currentStep < steps.length) {
                const stepName = steps[currentStep];
                const stepElement = stepElements[stepName];
                
                if (stepElement) stepElement.classList.add('active');
                if (progressFill) progressFill.style.width = `${((currentStep + 1) / steps.length) * 100}%`;
                if (deliveryTimeElement) {
                    const remainingTime = Math.max(0, 12 - (currentStep * 3));
                    deliveryTimeElement.textContent = remainingTime > 0 ? `${remainingTime} mins` : 'Delivered!';
                }
                
                currentStep++;
                if (currentStep < steps.length) {
                    setTimeout(updateProgress, 3000);
                } else {
                    Utils.showToast('Order delivered successfully!');
                }
            }
        };
        
        setTimeout(updateProgress, 2000);
    }
};

// User Management
const UserManager = {
    init: () => {
        AppState.currentUser = Storage.load('currentUser');
        UserManager.updateProfileDisplay();
    },
    
    login: (phoneNumber) => {
        Utils.showLoading();
        setTimeout(() => {
            const user = { id: Utils.generateId(), phone: phoneNumber, name: 'User', isLoggedIn: true };
            AppState.currentUser = user;
            Storage.save('currentUser', user);
            Utils.hideLoading();
            Utils.showToast('Login successful!');
            UserManager.updateProfileDisplay();
        }, 1500);
    },
    
    signup: (name, phone, email) => {
        Utils.showLoading();
        setTimeout(() => {
            const user = { id: Utils.generateId(), name, phone, email, isLoggedIn: true };
            AppState.currentUser = user;
            Storage.save('currentUser', user);
            Utils.hideLoading();
            Utils.showToast('Account created successfully!');
            UserManager.updateProfileDisplay();
        }, 1500);
    },
    
    logout: () => {
        AppState.currentUser = null;
        Storage.remove('currentUser');
        UserManager.updateProfileDisplay();
        Utils.showToast('Logged out successfully');
    },
    
    updateProfileDisplay: () => {
        const loginForm = document.getElementById('login-form');
        const signupForm = document.getElementById('signup-form');
        const userDashboard = document.getElementById('user-dashboard');
        
        if (AppState.currentUser && AppState.currentUser.isLoggedIn) {
            if (loginForm) loginForm.classList.add('hidden');
            if (signupForm) signupForm.classList.add('hidden');
            if (userDashboard) userDashboard.classList.remove('hidden');
            UserManager.populateUserDashboard();
        } else {
            if (loginForm) loginForm.classList.remove('hidden');
            if (signupForm) signupForm.classList.add('hidden');
            if (userDashboard) userDashboard.classList.add('hidden');
        }
    },
    
    populateUserDashboard: () => {
        const user = AppState.currentUser;
        if (!user) return;
        
        const userNameElement = document.getElementById('user-name');
        const userPhoneElement = document.getElementById('user-phone');
        const userAvatarElement = document.getElementById('user-avatar-text');
        
        if (userNameElement) userNameElement.textContent = user.name;
        if (userPhoneElement) userPhoneElement.textContent = user.phone;
        if (userAvatarElement) userAvatarElement.textContent = user.name.charAt(0).toUpperCase();
        
        UserManager.renderOrderHistory();
    },
    
    renderOrderHistory: () => {
        const recentOrders = document.getElementById('recent-orders');
        if (!recentOrders) return;
        
        const orderHistory = Storage.load('orderHistory', []);
        
        if (orderHistory.length === 0) {
            recentOrders.innerHTML = '<div class="no-orders">No orders yet</div>';
        } else {
            recentOrders.innerHTML = orderHistory.slice(0, 5).map(order => `
                <div class="order-item">
                    <div class="order-info-text">
                        <div class="order-id">Order #${order.id}</div>
                        <div class="order-date">${new Date(order.timestamp).toLocaleDateString()}</div>
                    </div>
                    <div class="order-status delivered">Delivered</div>
                </div>
            `).join('');
        }
    }
};

// Location Management
const LocationManager = {
    init: () => {
        AppState.locations = PRODUCT_DATA.locations;
        AppState.currentLocation = Storage.load('currentLocation') || AppState.locations[0];
        LocationManager.updateLocationDisplay();
        LocationManager.renderLocationModal();
    },
    
    updateLocationDisplay: () => {
        const locationNameElement = document.getElementById('current-location');
        if (locationNameElement && AppState.currentLocation) {
            locationNameElement.textContent = AppState.currentLocation.name;
        }
    },
    
    renderLocationModal: () => {
        const locationsList = document.getElementById('locations-list');
        if (!locationsList) return;
        
        locationsList.innerHTML = AppState.locations.map(location => `
            <div class="location-item ${AppState.currentLocation?.id === location.id ? 'active' : ''}" 
                 onclick="LocationManager.selectLocation(${location.id})">
                <div class="location-item-info">
                    <div class="location-item-name">${location.name}</div>
                    <div class="location-item-time">Delivery in ${location.deliveryTime}</div>
                </div>
            </div>
        `).join('');
    },
    
    selectLocation: (locationId) => {
        const location = AppState.locations.find(loc => loc.id === locationId);
        if (location) {
            AppState.currentLocation = location;
            Storage.save('currentLocation', location);
            LocationManager.updateLocationDisplay();
            LocationManager.renderLocationModal();
            ModalManager.closeModal('location-modal');
            Utils.showToast(`Location changed to ${location.name}`);
        }
    }
};

// Modal Management
const ModalManager = {
    showModal: (modalId) => {
        const modal = document.getElementById(modalId);
        if (modal) modal.classList.remove('hidden');
    },
    
    closeModal: (modalId) => {
        const modal = document.getElementById(modalId);
        if (modal) modal.classList.add('hidden');
    }
};

// Global functions for HTML onclick handlers
window.ProductManager = ProductManager;
window.CartManager = CartManager;
window.SearchManager = SearchManager;
window.LocationManager = LocationManager;
window.Navigation = Navigation;

// Application Initialization
const App = {
    init: () => {
        console.log('Initializing Zepto App...');
        Utils.showLoading();
        
        // Initialize all managers
        LocationManager.init();
        UserManager.init();
        CartManager.init();
        SearchManager.init();
        ProductManager.init();
        
        // Set up event listeners
        App.setupEventListeners();
        
        // Show home page
        Navigation.showPage('home');
        
        Utils.hideLoading();
        setTimeout(() => Utils.showToast('Welcome to Zepto! 🛒'), 500);
    },
    
    setupEventListeners: () => {
        // Navigation
        const startShoppingBtn = document.getElementById('start-shopping-btn');
        const viewAllBtn = document.getElementById('view-all-btn');
        const cartBtn = document.getElementById('cart-btn');
        const profileBtn = document.getElementById('profile-btn');
        const logo = document.querySelector('.logo');
        
        if (startShoppingBtn) startShoppingBtn.onclick = () => Navigation.showPage('products');
        if (viewAllBtn) viewAllBtn.onclick = () => Navigation.showPage('products');
        if (cartBtn) cartBtn.onclick = () => Navigation.showPage('cart');
        if (profileBtn) profileBtn.onclick = () => Navigation.showPage('profile');
        if (logo) {
            logo.onclick = () => Navigation.showPage('home');
            logo.style.cursor = 'pointer';
        }
        
        // Back buttons
        const backBtns = document.querySelectorAll('.back-btn');
        backBtns.forEach(btn => btn.onclick = Navigation.goBack);
        
        // Cart actions
        const shopNowBtn = document.getElementById('shop-now-btn');
        const checkoutBtn = document.getElementById('checkout-btn');
        const placeOrderBtn = document.getElementById('place-order-btn');
        
        if (shopNowBtn) shopNowBtn.onclick = () => Navigation.showPage('products');
        if (checkoutBtn) checkoutBtn.onclick = () => Navigation.showPage('checkout');
        if (placeOrderBtn) placeOrderBtn.onclick = CheckoutManager.processOrder;
        
        // Location
        const changeLocationBtn = document.getElementById('change-location-btn');
        const closeLocationModal = document.getElementById('close-location-modal');
        const locationModalBackdrop = document.getElementById('location-modal-backdrop');
        
        if (changeLocationBtn) changeLocationBtn.onclick = () => ModalManager.showModal('location-modal');
        if (closeLocationModal) closeLocationModal.onclick = () => ModalManager.closeModal('location-modal');
        if (locationModalBackdrop) locationModalBackdrop.onclick = () => ModalManager.closeModal('location-modal');
        
        // Auth
        const showSignup = document.getElementById('show-signup');
        const showLogin = document.getElementById('show-login');
        const logoutBtn = document.getElementById('logout-btn');
        const loginForm = document.getElementById('login-form-element');
        const signupForm = document.getElementById('signup-form-element');
        
        if (showSignup) {
            showSignup.onclick = (e) => {
                e.preventDefault();
                document.getElementById('login-form').classList.add('hidden');
                document.getElementById('signup-form').classList.remove('hidden');
            };
        }
        
        if (showLogin) {
            showLogin.onclick = (e) => {
                e.preventDefault();
                document.getElementById('signup-form').classList.add('hidden');
                document.getElementById('login-form').classList.remove('hidden');
            };
        }
        
        if (logoutBtn) logoutBtn.onclick = UserManager.logout;
        
        if (loginForm) {
            loginForm.onsubmit = (e) => {
                e.preventDefault();
                const phone = document.getElementById('login-phone').value;
                UserManager.login(phone);
            };
        }
        
        if (signupForm) {
            signupForm.onsubmit = (e) => {
                e.preventDefault();
                const name = document.getElementById('signup-name').value;
                const phone = document.getElementById('signup-phone').value;
                const email = document.getElementById('signup-email').value;
                UserManager.signup(name, phone, email);
            };
        }
    }
};

// Start the application when DOM is loaded
document.addEventListener('DOMContentLoaded', App.init);